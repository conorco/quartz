package tp1;

public class Exe1 {
	//Hello World !

	public static void main(String[] args) {
		System.out.println("Hello World!"); 
	}
}
