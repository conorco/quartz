package tp1;
import java.util.Scanner;

public class Exe2 {
	//Sasie et opérations de base

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//println affiche sur une nouvelle ligne à chaque fois, évite d'utiliser 
		System.out.println("Entrer un nombre entier");
		int a = sc.nextInt();
		System.out.println("Entrer un nombre entier");
		int b = sc.nextInt();
		//afficher les valeurs de a et b
		System.out.println("a="+ a +" b ="+b);
		int c = a;
		a = b;
		b = c;
		System.out.println("Echange des valeurs entre a et b");
		System.out.println("a="+ a +" b ="+b);
		System.out.println("double de a="+ 2*a +" moitié de b= ="+ b/2);
		System.out.println("quotient a/b "+ a/b +" reste de a/b "+ a%b);
		System.out.println("Plus grande valeur entre a et b : ");
		if (a>b) {
			System.out.println("a =" + a);
		}
		else {
			System.out.println("b =" + b);
		}
		
			
			



		sc.close();
	}
}
