package tp1;
import java.util.Scanner;

public class Exe3 {
	//Année bissextile

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrer un nombre entier");
		int annee = sc.nextInt();
		//Une ann ́ee est bissextile
		//— si elle est divisible par 4 et non divisible par 100, ou
		//— si elle est divisible par 400.
		if ((annee%4==0 && annee%100!=0) || (annee%400==0)) {
			System.out.println("Le nombre "+annee+" est une année bissextile");
		}
		else {
			System.out.println("Le nombre "+annee+" n'est une pas une année bissextile");
		}


		sc.close();
	}
}
