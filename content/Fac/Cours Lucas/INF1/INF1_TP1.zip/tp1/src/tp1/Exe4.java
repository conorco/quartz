package tp1;

import java.util.Scanner;

public class Exe4 {
	//Parité d'une somme

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Entrer un nombre entier");
		int a = sc.nextInt();
		System.out.print("Entrer un nombre entier");
		int b = sc.nextInt();
		System.out.print("Entrer un nombre entier");
		int c = sc.nextInt();
		
		int somme = a+b+c;
		if (somme%2==0) {
			System.out.print("La somme des trois entiers est paire");
		}
		else {
			System.out.print("La somme des trois entiers est impaire");
		}
		
		
		
		
		
		
		sc.close();
	}
	
	
}
