package tp1;
import java.util.Scanner;
public class Exe5 {
	//Affichage dans l'ordre croissant

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Entrer un nombre entier");
		int a = sc.nextInt();
		System.out.print("Entrer un nombre entier");
		int b = sc.nextInt();
		System.out.print("Entrer un nombre entier");
		int c = sc.nextInt();
		//System.out.println(c + " <= " + b + " <= " + a);
		if (a>=b) {
			if (b>=c) {
				System.out.println(c + " <= " + b + " <= " + a);
			}
			else if (c>=b && a>=c) {
				System.out.println(b + " <= " + c + " <= " + a);
			}
			else {
				System.out.println(b + " <= " + a + " <= " + c);
			}
		
		}
		else if(b>=a) {
			if (a>=c) {
				System.out.println(c + " <= " + a + " <= " + b);
			}
			else if (c>=a && b>=c) {
				System.out.println(a + " <= " + c + " <= " + b);
			}
			else {
				System.out.println(a + " <= " + b + " <= " + c);
			}
		}
		
			
		
		
		sc.close();
	}
}
