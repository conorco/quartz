package tp1;
import java.util.Scanner;
public class Exe6 {
	//Conversion secondes

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrer un nombre entier de secondes");
		int sec = sc.nextInt();
		int min = 0;
		int heure = 0;
		int jours = 0;
		if (sec>60) {
			min = sec/60; 
			sec = sec%60; 
			if (min>60) {
				heure = min/60;
				min = min%60;
				if (heure>24) {
					jours = heure/24;
					heure= heure%24;
				}
			}
		}
		System.out.println("Cela donne "+jours+" jours "+heure+" heures "+min+" minutes "+sec+" secondes ");
		
			
		
		
		
		sc.close();
	}
}
