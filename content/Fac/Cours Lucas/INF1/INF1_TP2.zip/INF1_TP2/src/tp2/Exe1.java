package tp2;

public class Exe1 {
	//Précision et variables de type double

	public static void main(String[] args) {
		double x = 0;
		for(int i=0; i<10; i++) {
			x+=0.1;
			System.out.println(x);
		}
	}

}

/* retourne :
0.1
0.2
0.30000000000000004
0.4
0.5
0.6
0.7
0.7999999999999999
0.8999999999999999
0.9999999999999999

on constate qu'il y a des approximations pour certaines valeurs
*/