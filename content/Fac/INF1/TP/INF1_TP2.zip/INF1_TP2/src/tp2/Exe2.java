package tp2;

public class Exe2 {
	//Conversion degrés Fahrenheit vers Celsius
	
	public static void main(String[] args) {
		double degre_C;
		for(double degre_F = 250; degre_F > -30 ; degre_F -=10) {
			degre_C = (5.0 / (double) 9)*degre_F - ((double)160 /(double)9);
			//(double) permet de garder des float sinon diviser des entiers --> 0
			System.out.println(degre_F+ " degrés F --> "+degre_C+" degrés C");
		}
	}

}
