package tp2;
import java.util.Scanner;

public class Exe3 {
	// Somme de 1 à n
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrer un nombre entier");
		int n = sc.nextInt();
		String resultat ="";
		int res=0;
		for(int i = 1; i<n+1 ; i++) {
			if (i==n){
				resultat += i+ " = ";
			}
			else {
				resultat += i+ " + ";
			}
			res+=i;
		}
		
		System.out.println(resultat+res);
		
		
		sc.close();
	}

}
