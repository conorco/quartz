package tp2;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class Exe4 {

	// Deviner le nombre

	/**
	 * Retourne un entier aléatoire entre a (inclus) et b (inclus)
	 * 
	 * @param a un entier positif
	 * @param b un entier positif
	 * @return Un entier aléatoire entre a (inclus) et b (inclus)
	 */
	public static int entierAleatoire(int a, int b) {
		return ThreadLocalRandom.current().nextInt(a, b + 1);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrer un nombre entier");
		int n = sc.nextInt();
		
		int inconnu = entierAleatoire(1,1);
		
		while(n!= inconnu) {
			if(n > inconnu) System.out.println("Trop grand !");
			else System.out.println("Trop petit !");
			System.out.println("Entrer un nombre entier");
			n = sc.nextInt();
		}
		System.out.println("Gagné !");	
		
		sc.close();
	}
}
