package tp2;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Exe5 {

	// Figures d'étoiles 
	
	
	// fonction qui permet de répéter une string
	public static String repeat(String str, int b) {
		String symbole = str; // symbole à répéter
		if(b!=0) {
			for(int i=0; i<b-1; i++) {
				str += symbole; // on ajoute le symbole à la string
			}
			return str;
		}
		else return ""; //ne pas répéter si 0 répétition
		
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrer un nombre entier >= 1");
		int h = sc.nextInt();
		String et = "*";
		String esp = " ";
		
		// première figure
		for(int i =h; i>0; i--) {
			System.out.println(repeat(et,i)+repeat(esp,h-i));
		}
		
		// deuxième figure
		for(int i=0; i<h;i++) {
			if (i==0 | i==h-1) {
				System.out.println(repeat(et,h));
			}
			else {
				System.out.println(et+repeat(esp,h-2)+et);
			}
		}
		
		//troisième figure
		for(int i=0; i<h;i++) {
			if (i==0 | i==h-1) {
				System.out.println(repeat(et,h));
			}
			else {
				System.out.println(repeat(esp,h-i-1)+et+repeat(esp,i));
			}
		}
		
		//quatrième figure
		int s=0;
		for (int i=1; i<2*h;i+=2) {
			System.out.println(repeat(esp,h-s-1)+repeat(et,i));
			s++;
		}
		
		//cinquième figure
		
		int p= h-2;
		for(int i=0; i<h;i++) {
			 //pour calculer le nombre d'espaces correspondants
			if(i==0 | i==h-1) System.out.println(et+repeat(esp,h-2)+et);
			else System.out.println(et+repeat(esp,i-1)+et+repeat(esp,p)+et);
			p--;
		}
		
		sc.close();

	}
}
