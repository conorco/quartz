package tp3;

public class Exe1 {

	public static void enumereCroissante(int vMin, int vMax) {
		for (int i=vMin ; i<=vMax ; i++) System.out.println(i);
	}
	
	public static void enumereDecroissante(int vMax,int vMin) {
		for (int i = vMax; i>=vMin ; i--) System.out.println(i);
	}
	
	public static void enumere(int deb, int fin) {
		if (deb <= fin) enumereCroissante(deb,fin);
		else enumereDecroissante(deb, fin);
	}
	
	public static void main(String[] args) {
		// tests ici
		enumere(10,-5);
		enumere(10,5);
		enumereDecroissante(10,5);
	}
}
