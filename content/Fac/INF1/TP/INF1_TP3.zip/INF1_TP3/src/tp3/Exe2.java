package tp3;

public class Exe2 {

	// Q1 : Écrire une fonction impotMontant qui prend en entrée le salaire d'une
	// personne et qui retourne le montant de son impôt.

	public static double impotMontant(double salaire) {
		double impot = 0;
		if (salaire<10064) return 0;
		else if (salaire < 25659) {
			impot = (salaire - 10064)*0.11;
		}
		else if (salaire < 73369) {
			impot= (25659-10064)*0.11 +(salaire - 25659)*0.3;
		}
		
		else if (salaire < 157805) {
			impot= (25659-10064)*0.11 +(73369 - 25659)*0.3 + (salaire - 73369)*0.41;
		}
		else {
			impot= (25659-10064)*0.11 +(73369 - 25659)*0.3 + (157805 - 73369)*0.41 + (salaire - 157805)*0.45;
		}
		return impot;
	}

	// Q2: Écrire une fonction pourcentageImposition, qui prend en entrée le salaire
	// d'une personne et qui retourne son pourcentage d'imposition.

	public static double pourcentageImposition(double salaire) {
		double pourcentage = impotMontant(salaire)/salaire;
		return pourcentage*100;
	}

	// Q3 : Écrire la fonction gainMariage pour calculer le gain d'impot des couples
	public static double gainMariage(double salaire1, double salaire2) {
		double gain = 0; 
		double impot_celib1 = impotMontant(salaire1);
		double impot_celib2 = impotMontant(salaire2);
		double impot_couple = 2*impotMontant((salaire1+salaire2)/2);
		gain = (impot_celib1 + impot_celib2) - impot_couple;
		return gain;
	}

	public static void main(String[] args) {
		// Tester vos fonctions ici sur quelques exemples
		double x = impotMontant(32000);
		System.out.println(x);
		double pourc = pourcentageImposition(32000);
		System.out.println(pourc);
		
		double gain_couple = gainMariage(10000,15000);
		System.out.println("En se mariant, ce couple gagne "+gain_couple+" € d'impôts");
	}
}
