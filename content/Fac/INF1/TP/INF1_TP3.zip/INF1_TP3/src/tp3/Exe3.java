package tp3;

public class Exe3 {

	/*
	 ligne 1 :      1111111                       
ligne 2 : 1     22222    1	 fin Aug : 2   debut Diminution : 7
ligne 3 : 12     333    21	fin Aug : 3		debut Diminution : 6
ligne 4 : 123    4     321	fin Aug : 4		debut Diminution :5
ligne 5 : 12    333     21	etc
ligne 6 : 1    22222     1
ligne 7 :     1111111

finAug = numLigne ; debDiminution = dim - (numLigne+1)

	 */
	
	// Q1 : Déterminer les dimensions de la cible en fonction de n
	
	// dimension de la cible  d'un carré de 2*n -1 de côté
	
	// Q2 : Écrire une fonction pour afficher la i-ème ligne de la cible

	public static void afficheLigne(int i, int n) {
		int dimension = 2*n - 1;
		int finCroissant = i;
		int debutDecroissant = dimension - (i+1);
		for (int k=1; k<=finCroissant;k++) {
			System.out.print(k+" ");
		}
		for (int k=finCroissant; k<=debutDecroissant;k++) {
			System.out.print(i+" ");
		}
		if(i==n) { // cas spécial quand i = n car redondance des boucles for
			debutDecroissant++;
			i--;
		};
		for (int k=debutDecroissant; k<dimension-1;k++) {

			System.out.print(i+" ");
			i--;
		}
		System.out.println(); // on saute une ligne
	}
	
	// Q2 : Écrire une fonction pour afficher la cible complète

	public static void cible(int n) {
		for(int i=1; i<=n; i++) afficheLigne(i,n); // on affiche le haut de la cible
		for(int i=n-1; i>0;i--) afficheLigne(i,n); // on affiche le bas de la cible
	}
	
	public static void main(String[] args) {
		// Tester ici vos fonctions
		
		//afficheLigne(1,4);
		cible(9);
	}
}
