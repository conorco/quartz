package main;

import util.ACX; // Pour charger les fonctions ACX.tracerRecherche
import java.util.Arrays; //pour copier un tableau

public class Main {

	public static int recherche(int cherche, int[] t){
        for(int i=0;i<t.length;i++){ // boucle qui parcourt tout le tableau
            if(t[i]==cherche){ // si la aleur du tableau à l'indice i est égale à cherche
                return i; 
            }
        }
    return -1;
	}
	
	public static int recherche2(int cherche, int[] t) {
		
		//cas particulier : tableau vide
		if (t.length ==0) return -1;
		// cas particulier : dernier élément = cherche
		if(cherche==t[t.length-1]) return t.length-1;
		//cas particulier : tableau avec un nombre d'éléments impair : on le transforme en tableau avec un nombre d'éléments pair
		if (cherche!=t[t.length-1] && t.length%2!=0) {
			int[] tab = new int[t.length-1]; // on crée un tableau temporaire de taille len(t)-1
			System.arraycopy(t, 0, tab, 0, t.length-1); // on copie t (moins son dernier élément) dans tab
			t= new int[tab.length]; // redimension de t pour correspondre à len(tab)
			System.arraycopy(tab, 0, t, 0, tab.length); // copie de tab dans t
		}
		int min =0; // initialisation à l'indice 0
		int max = t.length-1; // initialisation à l'indice len(t) - 1
		int milieu = 0; // initialisation de milieu à 0
		boolean valeur=false; // initialisation de la valeur trouvée à false
		while(!valeur && min<=max) { // tant que la valeur n'est pas trouvée et que min<=max (pour bien sortir de la boucle si la valeur ne se trouve pas dans le tableau)
			milieu = (max+min)/2; // milieu = indice du milieu du tableau (sachant que le tableau a un nombre d'éléments pairs)
			if (cherche==t[milieu]) valeur=true; //on a trouvé la valeur cherchée
			if (cherche<t[milieu]) max=milieu-1; //la valeur recherchée se trouve dans la partie inférieure du tableau donc on redéfinit max pour diviser par 2 la taille du tableau
			else min=milieu+1; // la valeur recherchée se trouve dans la partie supérieure du tableau donc on redéfinit min pour diviser par 2 la taille du tableau
		}
		if(valeur==true) return milieu; // si on a trouvé la valeur, on retourne milieu
		return -1; // sinon on retourne -1
	}
	
	
	// Les courbes de référence
	// f(x)=x/4500 , f(x) = log(x/100000)
	
	
	public static int RefLineaire(int x){return x/4500;}
	public static int RefLogarithmique(int x){return (int) Math.log(x/100000);}
	
	public static void main(String[] args) {
		// Un des tests utilisés
		int[] t = { -8, 4, 18, 22,23};
		int y=recherche2(22, t);
		System.out.println(y);
		
		
		// Traçage des courbes de temps de calcul
		String[] fonctions= {"recherche","recherche2"};  
		String[] reference= {"RefLogarithmique","RefLineaire"};

		ACX.tracerRecherche(fonctions,reference);
	}
	
	
}
