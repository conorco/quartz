package pourDebug;

public class PourDebug {

	// Recherche qui sort de la boucle dès que l'index est trouvé
	public static int recherche(int cherche, int[] t){
		boolean trouve=false;
		int index=-1; //initialisation à -1 au cas où pas trouvé
		int i=0;
		while (i<t.length && !trouve){
			if (t[i]==cherche) { // manquait les accolades
				index=i;
				trouve=true;
			}
				
			i=i+1;	
		}				//deplacement du i = i+1
		return index;
	}
	
	// Recherche qui consulte 2 cases du tableau en même temps
		public static int recherche2(int cherche, int[] t){
			for (int i=0; i<t.length; i=i+2){		//probleme de la longeur de t.length -1
				if (t[i]==cherche) return i;
				else if (i+1<t.length && t[i+1]==cherche) return i+1; 
				// ajout d'une exception pour retourner -1 si le nombre n'est pas dedans, sinon erreur
				// t[i+1] est retourné à i alors qu'il devrait être retourné a i+1
			}
			return -1;
		}
	
	
	public static void main(String[] args) {
		// Sur recherche, 3 bugs à trouver
		System.out.println("recherche");
		int [] t1 = {1,2,3};
		
		// Si l'élément cherché n'est pas dans le tableau
		int i= recherche(4,t1);
		System.out.println(i);
		
		// Si l'élément cherché est dans le tableau mais pas le premier
		int j= recherche(3,t1);
		System.out.println(j);
		
		// Si l'élément cherché est le premier du tableau il n'est même pas 
		// visité
		int k= recherche(1,t1);
		System.out.println(k);
		
		
		// Sur recherche2, 2 bugs à trouver
		System.out.println("recherche2");
		
		int l= recherche2(3,t1);
		System.out.println(l); // le bug venait de le longeur de t.length -1 
		
		int m= recherche2(2,t1);
		System.out.println(m); // le bug venait du retour de i alors qu'on devait avoir return i+1;
	
		int o=recherche2(4,t1);
		System.out.println(o); // quand la valeur n'est pas présente
		
	}

}
