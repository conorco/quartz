package main;

import static org.junit.Assert.*;
import org.junit.Test;

public class MainTest {
	//recherche
	@Test
	public void test1() {
		int[] t = { 10, 4, -8, 2 };
		assertEquals(2, Main.recherche(-8, t));
	}
	@Test
	public void test2() {
		int[] t = { 10, 4, -8, 2 };
		assertEquals(-1, Main.recherche(15, t));
	}
	//recherche2
	@Test
	public void test3() { //valeur dans le tableau
		int[] t = { -8, 4, 18, 22, 45, 56, 78, 90, 765, 789, 987};
		assertEquals(10, Main.recherche2(987, t));
	}
	@Test
	public void test4() { //valeur pas dans le tableau
		int[] t = { -8, 4, 18, 22 };
		assertEquals(-1, Main.recherche2(15, t));
	}
	@Test
	public void test3bis() { //valeur dans le tableau
		int[] t = { -8, 4, 18, 22 };
		assertEquals(0, Main.recherche2(-8, t));
	}
	
	@Test
	public void test4bis() { //valeur dans le tableau impair
		int[] t = { -8, 4, 18, 22, 23};
		assertEquals(3, Main.recherche2(22, t));
	}
	@Test
	public void test5bis() { //valeur dans le tableau impair
		int[] t = { -8, 4, 18, 22, 23};
		assertEquals(2, Main.recherche2(18, t));
	}
	@Test
	public void test4ter() { //valeur dans le tableau impair
		int[] t = { -8, 4, 18, 22, 23};
		assertEquals(4, Main.recherche2(23, t));
	}
	// pourDebug
	//recherche
	@Test
	public void test5() {
		int [] t1 = {1,2,3};
		assertEquals(-1, pourDebug.PourDebug.recherche(0,t1));
	}
	@Test
	public void test6() {
		int [] t1 = {1,2,3};
		assertEquals(2, pourDebug.PourDebug.recherche(3,t1));
	}
	@Test
	public void test7() {
		int [] t1 = {1,2,3};
		assertEquals(0, pourDebug.PourDebug.recherche(1,t1));
	}
	//recherche 2
	@Test
	public void test8() {
		int [] t1 = {1,2,3};
		assertEquals(-1, pourDebug.PourDebug.recherche2(0,t1));
	}
	@Test
	public void test9() {
		int [] t1 = {1,2,3};
		assertEquals(2, pourDebug.PourDebug.recherche2(3,t1));
	}
	@Test
	public void test10() {
		int [] t1 = {1,2,3};
		assertEquals(0, pourDebug.PourDebug.recherche2(1,t1));
	}
}
